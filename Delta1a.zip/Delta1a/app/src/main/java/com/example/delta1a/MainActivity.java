package com.example.delta1a;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView scrCount = (TextView) findViewById(R.id.scoreCounter);

        TextView tv_date = (TextView) findViewById(R.id.tv_date);

        final String stringDate = generateRandomDate();
        tv_date.setText(stringDate);

        final String[] arrOfStr = stringDate.split("-", 3);
        final int[] day = {Integer.parseInt(arrOfStr[0])};
        final int[] month = {Integer.parseInt(arrOfStr[1])};
        final int[] year = {Integer.parseInt(arrOfStr[2])};

        final String[] stringDay = {daysOfWeek(day[0], month[0], year[0])};


        Button checkButton = (Button) findViewById(R.id.button);

        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);

        RadioButton option1 = (RadioButton) findViewById(R.id.radioButton6);
        RadioButton option2 = (RadioButton) findViewById(R.id.radioButton7);
        RadioButton option3 = (RadioButton) findViewById(R.id.radioButton8);
        RadioButton option4 = (RadioButton) findViewById(R.id.radioButton9);

        final String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

        shuffle(days);

        option1.setText(days[0]);
        option2.setText(days[1]);
        option3.setText(days[2]);
        option4.setText(days[3]);

        scrCount.setText("SCORE : 0");

        final int[] score = {0};

        checkButton.setOnClickListener(v -> {
            int selectedId = radioGroup.getCheckedRadioButtonId();

            RadioButton radioButton = (RadioButton) findViewById(selectedId);
            if (radioButton.getText() == stringDay[0]) {

                radioButton.setChecked(false);
                score[0] +=1;
                scrCount.setText("SCORE : "+score[0]);

                shuffle(days);

                option1.setText(days[0]);
                option2.setText(days[1]);
                option3.setText(days[2]);
                option4.setText(days[3]);

                final String stringDate1 = generateRandomDate();
                tv_date.setText(stringDate1);

                final String[] arrOfStr1 = stringDate1.split("-", 3);
                day[0] = Integer.parseInt(arrOfStr1[0]);
                month[0] = Integer.parseInt(arrOfStr1[1]);
                year[0] = Integer.parseInt(arrOfStr1[2]);

                 stringDay[0] = daysOfWeek(day[0], month[0], year[0]);
            }
            else {
                Intent goToFinish = new Intent();
                goToFinish.setClass(getApplicationContext(),Delta1b.class);
                goToFinish.putExtra("dateScore",score[0]);
                startActivity(goToFinish);
            }
        });
    }



    private void shuffle(Object[] array){
        int noOfElements = array.length;
        for(int i=0;i<noOfElements;i++){
            int s = i + (int)(Math.random() * (noOfElements - i));
            Object temp = array[s];
            array[s] = array[i];
            array[i] = temp;
        }
    }

    private String generateRandomDate(){
        GregorianCalendar gc = new GregorianCalendar();

        int year = randBetween(1900,2100);
        gc.set(GregorianCalendar.YEAR,year);

        int dayOfYear = randBetween(1,gc.getActualMaximum(GregorianCalendar.DAY_OF_YEAR));
        gc.set(GregorianCalendar.DAY_OF_YEAR,dayOfYear);

        return gc.get(GregorianCalendar.DAY_OF_MONTH) + "-" +
                gc.get(GregorianCalendar.MONTH) + "-" +
                gc.get(GregorianCalendar.YEAR);
    }

    private static int randBetween(int start, int end){
        return start + (int) Math.round(Math.random() * (end - start)) ;
    }

    public String daysOfWeek(int day, int month, int year){
        Calendar c = Calendar.getInstance();
        c.set(year,month,day);
        String[] days = new String[]{"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
        int n;
        n = c.get(Calendar.DAY_OF_WEEK);
        return (days[n-1]);
    }

}
